[i,t,x,y,z]=getInputs;
[i1,t1,x1,y1,z1]=convertTime(i,t,x,y,z);
displayTime(i1,t1,x1,y1,z1)