function [hours,minutes,seconds,format,timeOfDay] = getInputs()


[i,t,x,y,z]=clockFunc;

hours=i;
minutes=t;
seconds=x;
format=y;
timeOfDay=z;




end