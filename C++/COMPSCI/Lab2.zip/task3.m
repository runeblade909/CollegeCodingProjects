% % In a script task3.m, plot the sin(x) graph like Figure 1 as x ranges from 0 to 6 and the value of x increases
% by 0.1

clc
clear
x=0:0.1:6
y=sin(x)
plot(x,y,'-')
