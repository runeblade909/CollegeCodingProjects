%Task3.m
%By: Zak Reichenbach
%9/26/2019
%trasposmat(x) takes an imput of x=3x3 vector and transposes it.

function[Y] = transposemat(x)


Y=[x(1,1),x(2,1),x(3,1);x(1,2),x(2,2),x(3,2);x(1,3),x(2,3),x(3,3)];
end





