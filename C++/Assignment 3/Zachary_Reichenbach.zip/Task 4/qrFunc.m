%By Zak Reichenbach
%9/19/2019
function[Q,R]=qrFunc(x,y)
R=rem(x,y);
Q=fix(x/y);

end