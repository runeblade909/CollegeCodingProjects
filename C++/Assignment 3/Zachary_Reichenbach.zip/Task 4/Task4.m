%By Zak Reichenbach
%9/19/2019


% This code is going to adress the user, cleverly, and then run the code
% for easterSunday
clc
clear

fprintf('Okay! I have been made to find what the date of Easter sunday is.\n')
fprintf('Feels kinda weird if your not christian but MOVING ON!\n')
fprintf('What year are we shooting for here mate?\n')
easterSunday