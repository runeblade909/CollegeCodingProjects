%By Zak Reichenbach
%9/19/2019

function[out] = BMI(weight,height)
weight=input('What is your weight(kg)? \n');
height=input('How tall are you(m)? \n');
out=(weight/(height)^2);

end
