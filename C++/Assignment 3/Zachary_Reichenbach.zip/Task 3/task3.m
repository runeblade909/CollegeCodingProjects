%By Zak Reichenbach
%9/19/2019

clc
clear

fprintf('Hi there! I would like to figure out what you \nBMI is. Just for science purposes.\n')
run=BMI;
fprintf('Your BMI is %.2f.',run)


