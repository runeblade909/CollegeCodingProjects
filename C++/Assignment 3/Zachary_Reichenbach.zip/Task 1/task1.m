%By Zak Reichenbach
%9/19/2019
clc 
clear

fprintf('Hi there! I do basic math, so cool!\n')
x=input('Give me my first number!\n');
y=input('Keep it rolling fam!\n');
addFunc(x,y)
subtractFunc(x,y)
multFunc(x,y)
divbyFunc(x,y)
