%By Zak Reichenbach
%9/19/2019

function [out] = addFunc(x,y)
fprintf('%d+%d',x,y);
out=x+y;
end
