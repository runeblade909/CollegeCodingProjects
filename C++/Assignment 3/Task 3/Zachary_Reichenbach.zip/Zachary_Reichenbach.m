
clc
clear


start_number=randi([1,5]);
step_number=randi([1,3]);
end_number=randi([20,50]);
chaos_value=chaos_function(start_number,step_number,end_number)
