#include <iostream>
#include <string>

using namespace std;

string accountArray[100] = {};
int N = 100;

int swapValues(string accountArray[],int size);

int main() {


    swapValues(accountArray,N);



    return 0;
}

int swapValues(string accountArray[],int size){
//intake data from given account in gambling
//Get index of account balance
//Search accountArray for other strings that match
// find the index of the found account, or say "your the only person with that name"
// swap the values using the indexes in the accountArray matrix and a dumby variable
cout << "You have switched bank account balances with an even poorer man....." << endl;
cout << "You have 1 dollar, RIP." << endl;


}

