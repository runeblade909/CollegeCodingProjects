#include <iostream>
#include <ctime>
#include "Functions.cpp"


using namespace std;

int Main(){
    int const N = 6;
    int myArray[] = {1,2,3,4,5,6};
    for (int i=0 ; i<=N;){
    menuChoice=myArray[i];
    cout << myArray[i];
    menuTest(myArray,N);
  i=i++;
 }
 
return 0;

}