%Assignment 6

clc
clear

[audioVec,Fs]=audioread('talkieMono.wav');
choice=1;
player=audioplayer(audioVec,Fs);

while choice ~= 0
    choice = menu('What would you like to do?',...
        'Play Audio',...
        'audioEcho',...
        'Compress',...
        'fftBar');
    switch choice
        case 1
            player=audioplayer(audioVec,Fs);
            play(player);
        case 2
            audioEcho()
        case 3
            compress()
        case 4 
            fftBar()            
    end
end