function [z] = fftBar(wav,Fs)
%take in audio vector and sampling frequency
%Only use the first 1000 samples of the audio vector
%use fast fourier transform function (fft) to convert the audio
%signal into a frequency domain
%fft will return a frequency domain, containing both real and imaginary
%parts. Take the ABS() to get rid of imaginary things.

%Only want the positive parts of the fft func, so create a vector only
%containing the positive parts ( the first half of the vec)

%create a frequency vector, f=Fs*(0:(length(y)-1)/2)/length(y);

%create a bar graph

z=('OH LAWD'); %Dummy Data

end
