function [s] = compress(wav,Fs)
%Read audio clip, take in file
%take in compression ratio
%Convert to new audio ratio

s=('COMPRESS'); %dummy data
end