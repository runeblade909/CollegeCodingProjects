function [x] = audioEcho(wav,Fs)
%play audio clip
%delay the audio clip, lower the sound
%play the clip a second time with above changes


x=('ECHO'); %Dummy Data

end