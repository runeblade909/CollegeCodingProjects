#include <iostream>
using namespace std;

int main(){


    cout << "hello my dude ;)" << endl;

    return 0;
    

}