clear; clc; close all;

monteCarloSims = 1;

set(0,'defaultTextInterpreter','latex')
filenames = ["Aluminum 25V 240mA","Aluminum 28V 269mA","Brass 26V 245mA",...
    "Brass 29V 273mA","Steel 21V 192mA"];
n = 100;
H_vals = [91.1 114.3 109.3 135.9 491.2];
I_vals = [0.240 0.269 0.245 0.273 0.192];
V_vals = [25 28 26 29 21];
k_vals = [130 130 115 115 16.2];

tiles = tiledlayout('flow');
tiles.TileSpacing = 'compact';
tiles.Padding = 'compact';
for index = 1:5
%Get Data for Iteration
%index = 1;
nexttile;
filename = filenames(index);
H_anal = H_vals(index);
I = I_vals(index); %Amps
V = V_vals(index); %Volts
k = k_vals(index); %W/mK
D = 0.0254; %Meters

%Find Analyitical Errors
deltaV = 0.05; %Volts
deltaI = 0.0001; %Amps
deltaK = 0.05 * k; %W/mK
deltaD = 0.001; %meters

partial_V = (4 * I) / (k * pi * D^2);
partial_I = (4 * V) / (k * pi * D^2);
partial_K = (-4 * I * V) / (pi * D^2 * k^2);
partial_D = (-8 * I * V) / (pi * D^3 * k);

error_T0_anal = 2; %+/- 2 degrees celsius
error_H_anal = sqrt( (partial_V * deltaV)^2 + (partial_I * deltaI)^2 + ...
        (partial_K * deltaK)^2 + (partial_D * deltaD)^2);

%Load Data
data = readtable(filename);
varNames = ["time","TC0","TC1","TC2","TC3","TC4","TC5","TC6","TC7","TC8"];
data.Properties.VariableNames = varNames;

%Thermocouple error
T_error = 2; %+/- 2 degrees celsius

%Get last row of data
data = table2array(data(end, 2:end));
xPositions = [0 1.375:0.5:4.875] / 39.370; %Inches
%Monte Carlo Simulation
for i = 1:monteCarloSims
    %Create array of random temperature variations that is +/- T_error
    variation = ((rand(1, 9) * 2) - 1) * T_error;
    new_temps = data + variation;
    
    %Perform Linear Fit of New Temperature Data Set
    Linear_Fit = fitlm(xPositions,new_temps);
    T0_MC(i) = Linear_Fit.Coefficients.Estimate(1);
    H_MC(i) = Linear_Fit.Coefficients.Estimate(2);
end
Linear_Fit = fitlm(xPositions, data);
T0_exp = Linear_Fit.Coefficients.Estimate(1);
H_exp = Linear_Fit.Coefficients.Estimate(2);

%Experimental Errors
error_T0_exp = (max(T0_MC) - min(T0_MC))/2;
error_H_exp = (max(H_MC) - min(H_MC))/2;
error_T0_exp = Linear_Fit.Coefficients.SE(1);
error_H_exp = Linear_Fit.Coefficients.SE(2);

disp("File: " + filename + "  T0 Error: " + error_T0_exp + "  H Error: " + error_H_exp);
%Plot Results on Figure
x = xPositions;
%Plot Error Regions First
    %Experimental Error
    upperBound = (T0_exp + error_T0_exp) + x * (H_exp + error_H_exp);
    lowerBound = (T0_exp - error_T0_exp) + x * (H_exp - error_H_exp);
    
    fill([x, fliplr(x)], [upperBound, fliplr(lowerBound)], [255 0 0]./255, 'EdgeAlpha', 0, 'FaceAlpha', 0.2);
    hold on;
    %Analytical Error
    upperBound = (T0_exp + error_T0_anal) + x * (H_anal + error_H_anal);
    lowerBound = (T0_exp - error_T0_anal) + x * (H_anal - error_H_anal);
    
    fill([x, fliplr(x)], [upperBound, fliplr(lowerBound)], [0 255 0]./255, 'EdgeAlpha', 0, 'FaceAlpha', 0.2);
    
    %Plot Analytical Solution
    plot(x, T0_exp + H_anal * x,':k', 'LineWidth', 2.5);
    
    %Plot Experimental Line of Best Fit
    plot(x, T0_exp + H_exp * x, 'k', 'LineWidth', 2.5);
    
    %Plot Experimental Data
    scatter(x, data, 40, 'filled', 'MarkerEdgeColor', [0, 0, 0], 'MarkerFaceColor', [1 1 1]);
    
    %Plot Style
    grid minor
    title(filename, 'FontSize', 22);
    xlim([min(x) max(x)]);
end

%Global Plot Formatting
%title(tiles, ["Steady State Solution Error", monteCarloSims + " Monte Carlo Simulations"], 'interpreter', 'latex', 'FontSize', 22);
title(tiles, ["Steady State Solution Error"], 'interpreter', 'latex', 'FontSize', 22);

legend(["Experimental Error", "Analytical Error", "Experimental Solution", "Analytical Solution", "Experimetal Data"], 'FontSize', 18);
xlabel(tiles, "X Position [Meters]", 'FontSize', 18, 'interpreter', 'latex');
ylabel(tiles, "Temperature [$^\circ$ C]", 'FontSize', 18, 'interpreter', 'latex');