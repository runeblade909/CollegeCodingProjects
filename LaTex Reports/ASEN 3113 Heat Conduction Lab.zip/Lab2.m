set(0,'defaultTextInterpreter','latex')
filenames = ["Aluminum 25V 240mA","Aluminum 28V 269mA","Brass 26V 245mA","Brass 29V 273mA","Steel 21V 192mA"];
n = 100;
H_anal = [2.315,2.9043,2.776,4.4509,12.4761];
i = 1;


t = tiledlayout(2,3);
title(t,"Steady State Solution")
for filename = filenames
data = readtable(filename);
varNames = ["time","TC0","TC1","TC2","TC3","TC4","TC5","TC6","TC7","TC8"];
data.Properties.VariableNames = varNames;

%% Q1
data = question1(data);
datas{i} = data;

nexttile;
x = linspace(0,4.875,n);
v = data.T0(end) + data.H(end)*x;
v_anal = data.T0(end) + H_anal(i)*x;
plot(x,v,'LineWidth',1.1)
hold on
plot(x,v_anal,'LineWidth',1.1)
scatter([0,1.375:.5:4.875],[data.T0(end),data{end,3:10}],'k')
title(filename)
xlabel("x-position (in)")
ylabel("Temperature")

disp(filename + ":")
disp("  T0 = " + data.T0(end) + "      H = " + data.H(end))
i = i+1;
set(gca,'FontSize',12)

end
legend(["Experimental Slope", "Analytical Slope","Experimental Data"])

%% Q2



%% Q5

for j = 1:4
data = datas{j};

figure;
hold on;
for i = 3:11
    plot(data.time, data{:,i})
end
title(filenames(j))

end




%% Functions
%Calculate T0 and H
function data = question1(data)
l = size(data,1);
data.T0 = zeros(l,1);
data.H = zeros(l,1);
for i = 1:l
    a = polyfit(1.375:.5:4.875,data{i,3:10},1);
    data.T0(i) = a(2);
    data.H(i) = a(1);
end
end