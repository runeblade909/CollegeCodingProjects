set(0,'defaultTextInterpreter','latex')
filenames = ["Aluminum 25V 240mA","Aluminum 28V 269mA","Brass 26V 245mA","Brass 29V 273mA","Steel 21V 192mA"];
n = 100;
H_anal = [2.315,2.9043,2.776,4.4509,12.4761];
i = 1;
T0_array = zeros(1,5);
H_array = zeros(1,5);
t = tiledlayout(2,3);
title(t,"Steady State Solution")
for filename = filenames
data = readtable(filename);
varNames = ["time","TC0","TC1","TC2","TC3","TC4","TC5","TC6","TC7","TC8"];
data.Properties.VariableNames = varNames;
%% Q1
data = question1(data);
datas{i} = data;
nexttile;
x = linspace(0,4.875,n);
v = data.T0(end) + data.H(end)*x;
v_anal = data.T0(end) + H_anal(i)*x;
plot(x,v,'LineWidth',1.1)
hold on
plot(x,v_anal,'LineWidth',1.1)
scatter([0,1.375:.5:4.875],[data.T0(end),data{end,3:10}],'k')
title(filename)
xlabel("x-position (in)")
ylabel("Temperature")
disp(filename + ":")
disp("  T0 = " + data.T0(end) + "      H = " + data.H(end))
T0_array(i) = data.T0(end);
H_array(i) = data.H(end);
i = i+1;
set(gca,'FontSize',12)
end
legend(["Experimental Slope", "Analytical Slope","Experimental Data"])
% Convert to *C/M
%% Question 2 Code:
%% 2a) Aluminum 25V 240 mA:
% Analytical Solution:
p_A = 2810;
c_A = 960;
k_A = 130;
alpha_A2 = k_A/(p_A*c_A);
L = 5.875*0.0254;
x_array = [1.375,1.875,2.375,2.875,3.375,3.875,4.375,4.875]*0.0254;
t_0 = 1;
figure();
t_vec = 1:2500;
n = 1;
Area = pi*(0.5)^2*0.00064516;
H = 25*240*10^-3/(k_A*Area);
T_0 =T0_array(1);
for index = 1:length(x_array)
b_n = 8*H*L*(-1)^(n)/((2*n-1)^2*(pi)^2);
lambda_n =(2*n-1)*pi/(2*L);
U_array(1) = T_0+H*x_array(index);
U_0 = U_array(1);
transient_calc = b_n*sin(lambda_n*x_array(index))*exp(-(lambda_n)^2*alpha_A2*t_vec)+T_0+H*x_array(index);
plot(t_vec,transient_calc);
hold on;
end
title(" Aluminum 25V 240mA:Temperature Reading [{\circ} C] vs Time [s]");
xlabel("Time [s]");
ylabel("Temperature Reading [{\circ} C]");
grid on
hold on
j = 1;
data = datas{j};
for i = 3:11
    plot(data.time, data{:,i})
end
%% 2b) Aluminum 28V 269mA
% Analytical Solution:
p_A = 2810;
c_A = 960;
k_A = 130;
alpha_A2 = k_A/(p_A*c_A);
L = 5.875*0.0254;
x_array = [1.375,1.875,2.375,2.875,3.375,3.875,4.375,4.875]*0.0254;
t_0 = 1;
figure();
t_vec = 1:2500;
n = 1;
Area = pi*(0.5)^2*0.00064516;
H = 28*268*10^-3/(k_A*Area);
for index = 1:length(x_array)
b_n = 8*H*L*(-1)^(n)/((2*n-1)^2*(pi)^2);
lambda_n =(2*n-1)*pi/(2*L);
U_array(1) = T_0+H*x_array(index);
U_0 = U_array(1);
transient_calc = b_n*sin(lambda_n*x_array(index))*exp(-(lambda_n)^2*alpha_A2*t_vec)+T_0+H*x_array(index);
plot(t_vec,transient_calc);
hold on;
end
title(" Aluminum 28V 269mA Temperature Reading [{\circ} C] vs Time [s]");
xlabel("Time [s]");
ylabel("Temperature Reading [{\circ} C]");
grid on
j = 2;
data = datas{j};
for i = 3:11
    plot(data.time, data{:,i})
end
%% 2c) Brass 26V 245mA
% Analytical Solution:
p_B = 8500;
c_B = 380;
k_B = 115;
alpha_A2 = k_B/(p_B*c_B);
L = 5.875*0.0254;
x_array = [1.375,1.875,2.375,2.875,3.375,3.875,4.375,4.875]*0.0254;
t_0 = 1;
figure();
t_vec = 1:2500;
n = 1;
Area = pi*(0.5)^2*0.00064516;
H = 26*245*10^-3/(k_A*Area);
for index = 1:length(x_array)
b_n = 8*H*L*(-1)^(n)/((2*n-1)^2*(pi)^2);
lambda_n =(2*n-1)*pi/(2*L);
U_array(1) = T_0+H*x_array(index);
U_0 = U_array(1);
transient_calc = b_n*sin(lambda_n*x_array(index))*exp(-(lambda_n)^2*alpha_A2*t_vec)+T_0+H*x_array(index);
plot(t_vec,transient_calc);
hold on;
end
title(" Brass 26V 245mA Temperature Reading [{\circ} C] vs Time [s]");
xlabel("Time [s]");
ylabel("Temperature Reading [{\circ} C]");
grid on
j = 3;
data = datas{j};
for i = 3:11
    plot(data.time, data{:,i})
end
%% 2d) Brass 29V 273mA
% Analytical Solution:
p_B = 8500;
c_B = 380;
k_B = 115;
alpha_A2 = k_B/(p_B*c_B);
L = 5.875*0.0254;
x_array = [1.375,1.875,2.375,2.875,3.375,3.875,4.375,4.875]*0.0254;
t_0 = 1;
figure();
t_vec = 1:2500;
n = 1;
Area = pi*(0.5)^2*0.00064516;
H = 29*273*10^-3/(k_A*Area);
for index = 1:length(x_array)
b_n = 8*H*L*(-1)^(n)/((2*n-1)^2*(pi)^2);
lambda_n =(2*n-1)*pi/(2*L);
U_array(1) = T_0+H*x_array(index);
U_0 = U_array(1);
transient_calc = b_n*sin(lambda_n*x_array(index))*exp(-(lambda_n)^2*alpha_A2*t_vec)+T_0+H*x_array(index);
plot(t_vec,transient_calc);
hold on;
end
title(" Brass 29V 273mA Temperature Reading [{\circ} C] vs Time [s]");
xlabel("Time [s]");
ylabel("Temperature Reading [{\circ} C]");
grid on
j = 4;
data = datas{j};
for i = 3:11
    plot(data.time, data{:,i})
end
%% 2e) Stainless Steel T-303 Annealed  21V 192mA
% Analytical Solution:
p_S = 8000;
c_S = 500;
k_S = 16.2;
alpha_A2 = k_S/(p_S*c_S);
L = 5.875*0.0254;
x_array = [1.375,1.875,2.375,2.875,3.375,3.875,4.375,4.875]*0.0254;
t_0 = 1;
figure();
t_vec = 1:14000;
n = 1;
Area = pi*(0.5)^2*0.00064516;
H = 21*192*10^-3/(k_S*Area);
for index = 1:length(x_array)
b_n = 8*H*L*(-1)^(n)/((2*n-1)^2*(pi)^2);
lambda_n =(2*n-1)*pi/(2*L);
U_array(1) = T_0+H*x_array(index);
U_0 = U_array(1);
transient_calc = b_n*sin(lambda_n*x_array(index))*exp(-(lambda_n)^2*alpha_A2*t_vec)+T_0+H*x_array(index);
plot(t_vec,transient_calc);
hold on;
end
title(" Stainless Steel T-303 Annealed  Temperature Reading [{\circ} C] vs Time [s]");
xlabel("Time [s]");
ylabel("Temperature Reading [{\circ} C]");
grid on
j = 5;
data = datas{j};
for i = 3:11
    plot(data.time, data{:,i})
end
%% Calculate T0 and H Function:
function data = question1(data)
l = size(data,1);
data.T0 = zeros(l,1);
data.H = zeros(l,1);
for i = 1:l
    a = polyfit(1.375:.5:4.875,data{i,3:10},1);
    data.T0(i) = a(2);
    data.H(i) = a(1);
end

end