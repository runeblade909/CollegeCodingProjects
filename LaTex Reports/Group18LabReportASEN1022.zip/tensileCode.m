%% Clean Up
clear
clc
close all


%% Reading in Data
brittleData = xlsread('ASEN1022_Feb21_Brittle_Data.csv');
ductileData = xlsread('ASEN1022_Jan28_Ductile_Data.csv');

disp_brittle = brittleData(:,4);
disp_ductile = ductileData(:,4);

load_brittle = brittleData(:,2);
load_ductile = ductileData(:,2);

%% contants
w_brittle = 0.504; %in
t_brittle = 0.187; % in
x_sec_br = w_brittle * t_brittle; %in^2


w_ductile = 0.500; %in
t_ductile = 0.191; %in
x_sec_du = w_ductile * t_ductile; %in^2

dogBone_L0 = 6; %in

%% Strain and Stress Calculations
%stress and strain calculations for brittle specimen
strain_brittle = disp_brittle;%./dogBone_L0; %in/in
stress_brittle = (load_brittle./x_sec_br)./1000; %ksi
max_stress_br = max(stress_brittle);
index_break_br = find(stress_brittle == max_stress_br);

%best fit line data brittle
index_end_b = 624;
BFLval_b = polyfit(strain_brittle(1:index_end_b),stress_brittle(1:index_end_b),1); %linear fit of the elastic region (slope,y-intercept)
BFLtb = BFLval_b(2) + BFLval_b(1).*(strain_brittle); %Stress Value of BFL
BFLb_offset = BFLval_b(1).*(strain_brittle-.002);

fprintf('Youngs Modulus for Brittle Specimen= %.3f \n',BFLval_b(1))
fprintf('Ultimate Strength for Brittle Specimen= %.3f \n',stress_brittle(index_break_br))
fprintf('Fracture Strength for Brittle Specimen= %.3f \n',stress_brittle(index_break_br))


%stress and strain calculations for extruded specimen
strain_ductile = disp_ductile;%./dogBone_L0; %in/in
stress_ductile = (load_ductile./x_sec_du)./1000; %ksi
%best fit line data extruded
index_end_e = 105;
BFLval_e = polyfit(strain_ductile(1:index_end_e),stress_ductile(1:index_end_e),1); %linear fit of the elastic region (slope,y-intercept)
% strain_te = linspace(0,0.018,635); %arbitrary strains to input into best fit line
BFLte = BFLval_e(2) + BFLval_e(1).*(strain_ductile); %Stress Value of BFL
BFLe_offset = BFLval_e(1).*(strain_ductile-.002);

%Yield Strength of extruded specimen
indexYielde = find( abs(BFLe_offset - stress_ductile) <= 1 );

%Ultimate Strength
IndexUSe = find(stress_ductile == max(stress_ductile));

fprintf('Youngs Modulus for Extruded Specimen= %.3f \n',BFLval_e(1))
fprintf('Yield Strength for Extruded Specimen= %.3f \n',stress_ductile(indexYielde))
fprintf('Ultimate Strength for Extruded Specimen= %.3f \n',stress_ductile(IndexUSe))
fprintf('Fracture Strength for Extruded Specimen= %.3f \n',stress_ductile(end-1))


%% Plots

%Brittle Stress-Strain Plot
figure(1)
scatter(strain_brittle(1:index_break_br),stress_brittle(1:index_break_br),5)
hold on
plot(strain_brittle,BFLtb,'LineWidth',1.) %best fit line ductile for elastic portion
scatter(strain_brittle(index_break_br),stress_brittle(index_break_br),80,'filled','LineWidth',5) %Ult/Frac strength point
xlabel('Strain (in/in)')
ylabel('Stress (ksi)')
title('Stress-Strain Plot of Brittle Specimen')
xlim([0,.006])
ylim([0,30])
legend('Stress-Strain Curve','Elastic Region Linear Fit','Ultimate/Fracture Strength','Location','Southeast')
hold off



%Extruded Stress-Strain Plot
truncateNum = 0;
figure(2)
scatter(strain_ductile(1:end-truncateNum),stress_ductile(1:end-truncateNum),5)
hold on
plot(strain_ductile,BFLte,'LineWidth',1.5) %best fit line ductile for elastic portion
plot(strain_ductile,BFLe_offset,'LineWidth',1.5) % 0.2% offset line 
scatter(strain_ductile(indexYielde),stress_ductile(indexYielde),80,'filled','LineWidth',5) %yield strength point
scatter(strain_ductile(IndexUSe),stress_ductile(IndexUSe),80,'filled','LineWidth',5) %Ultimate Stress Point
scatter(strain_ductile(end - 1),stress_ductile(end - 1),80,'filled','LineWidth',5) %Fracture Stress Point
xlabel('Strain (in/in)')
ylabel('Stress (ksi)')
title('Stress-Strain Plot of Extruded Specimen')
legend('Stress-Strain Curve','Elastic Region Linear Fit','0.2% Offset','Yield Strength','Ultimate Strength','Fracture Strength','Location','southeast')
xlim([0,.12])
ylim([0,5e1])
hold off





