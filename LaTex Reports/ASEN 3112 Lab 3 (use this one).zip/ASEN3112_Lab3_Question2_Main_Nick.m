%% ASEN 3112 - Lab 3
% Part 2: FEM Results - Resonant Frequencies

% Author: Akanksha Nelacanti & Zak Reichenbach
% Date Created: 04/08/2022
% Last Edited: 04/17/2022

clear
clc
close all

%% Givens

L = 12; % [in]
L_E = 4.5; % [in]
L_R = 5; % [in]
w = 1; % [in]
h = 1/8; % [in]
h_E = 1/4; % [in]
h_R = 0.040; % [in]
E = 10175000; % [psi]
rho = 0.0002505; % [lb-s^2 / in^4]
M_T = 1.131 * rho; % [lb-s^2 / in]
S_T = 0.5655 * rho; % [lb-s^2]
I_T = 23.124 * rho; % [lb-s^2-in]
A = w * h; % [in^2]
I_zz = (w * h^3) / 12; % [in^4]

%% Two-Element Model
% K_2 * U = (omega^2) * M_2 * U

% Coefficients
c_M2 = (rho * A * L) / 100800; % [lb-s^2 / in]
c_K2 = (4 * E * I_zz) / L^3; % [psi-in]

% Build M2 Matrix
M2 = c_M2 * [19272, 1458*L, 5928, -642*L, 0, 0;...
            1458*L, 172 * (L^2), 642 * L, -73 * (L^2), 0, 0;...
            5928, 642 * L, 38544, 0, 5928, -642 * L;...
            -642 * L, -73 * (L^2), 0, 344 * (L^2), 642 * L, -73 * (L^2);...
            0, 0, -24, -6 * L, 24, -6 * L;...
            0, 0, 6 * L, L^2, -6 * L, 2 * (L^2)];

extra = zeros(6,6);
extra(5,5) = M_T; extra(5,6) = S_T; extra(6,5) = S_T; extra(6,6) = I_T;

M2 = M2 + extra;
M_red2 = M2(3:end, 3:end);

% Build K2 matrix
K2 = c_K2 * [24, 6 * L, -24, 6 * L, 0, 0;...
            6 * L, 2 * (L^2), -6 * L, L^2, 0, 0;...
            -24, -6 * L, 48, 0, -24, 6 * L;...
            6 * L, L^2, 0, 4 * (L^2), -6 * L, L^2;...
            0, 0, -24, -6 * L, 24, -6 * L;...
            0, 0, 6 * L, L^2, -6 * L, 2 * (L^2)];
        
K_red2 = K2(3:end, 3:end);

% Find eigenvalues aka omega
[ev2, evec2] = eig(K_red2, M_red2);
w2 = real(sqrt(diag(evec2)));

% Convert from omega to frequencies [Hz]
freq2 = w2/(2*pi);

%% Four-Element Model
% K_4 * U = (omega^2) * M_4 * U

% Coefficients
c_M4 = (rho * A * L) / 806400; % [lb-s^2 / in]
c_K4 = (8 * E * I_zz) / L^3; % [psi-in]

% Build M4 Matrix

M4 = c_M4 * [77088, 2916*L,23712,-1284*L, 0, 0, 0, 0, 0, 0;
            2916*L, 172*L^2, 1284*L, -73*L^2, 0, 0, 0, 0, 0, 0;
            23712, 1284*L, 154176, 0, 23712, -1284*L, 0, 0, 0, 0;
            -1284*L, -73*L^2, 0, 344*L^2, 1284*L, -73*L^2, 0, 0, 0, 0;
            0, 0, 23712, 1284*L, 154176, 0, 23712, -1284*L, 0, 0;
            0, 0, -1284*L, -73*L^2, 0, 344*L^2, 1284*L, -73*L^2, 0, 0;
            0, 0, 0, 0, 23712, 1284*L, 154176, 0, 23712, -1284*L;
            0, 0, 0, 0, -1284*L, -73*L^2, 0, 344*L^2, 1284*L, -73*L^2;
            0, 0, 0, 0, 0, 0, 23712, 1284*L, 77088 , -2916*L;
            0, 0, 0, 0, 0, 0, -1284*L, -73*L^2, -2916*L , 172*L^2] ...
          + [0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ;
            0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ;
            0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ;
            0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ;
            0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ;
            0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ;
            0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ;
            0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ;
            0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , M_T,  S_T;
            0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , S_T,  I_T];
        
K4 = c_K4 * [ 96, 12*L, -96, 12*L, 0, 0, 0, 0, 0, 0;
            12*L, 2*L^2, -12*L,L^2, 0, 0, 0, 0, 0, 0;
            -96, -12*L, 192, 0, -96, 12*L, 0, 0, 0, 0;
            12*L,L^2, 0, 4*L^2, -12*L,L^2, 0, 0, 0, 0;
            0,  0, -96, -12*L, 192, 0, -96, 12*L, 0, 0;
            0, 0, 12*L,L^2, 0, 4*L^2, -12*L,L^2, 0, 0;
            0, 0, 0, 0, -96, -12*L, 192, 0, -96, 12*L;
            0, 0, 0, 0, 12*L,L^2, 0, 4*L^2, -12*L,L^2;
            0, 0, 0, 0, 0, 0, -96, -12*L, 96, -12*L;
            0, 0, 0, 0, 0, 0, 12*L,L^2, -12*L, 2*L^2;];

M_red4 = M4(3:end, 3:end);
K_red4 = K4(3:end, 3:end);


% Find eigenvalues aka omega
[ev4, evec4] = eig(K_red4, M_red4);
w4 = real(sqrt(diag(evec4)));

% Convert from omega to frequencies [Hz]
freq4 = w4/(2*pi);

%% Question 3 - Zak Reichenbach
% Plotting response for each frequency eigen mode

[x1,v1] = eigenmode(L,ev2(:,4),2,10,1);
[x2,v2] = eigenmode(L,ev2(:,3),2,10,-1);
[x3,v3] = eigenmode(L,ev2(:,2),2,10,1);

ModeFreq1 = freq2(4);
ModeFreq2 = freq2(3);
ModeFreq3 = freq2(2);

doug = sprintf('Mode Shape 1 %0.1f Hz',ModeFreq1);
dimma = sprintf('Mode Shape 2 %0.1f Hz',ModeFreq2);
dome = sprintf('Mode Shape 3 %0.1f Hz',ModeFreq3);


figure
title('Modal Response')
hold on
plot(x1,v1/(max(v1)))
plot(x2,v2/(-min(v2)))
plot(x3,v3/(max(v3)))
legend(doug,dimma,dome)
xlim([0 12])
grid on
hold off
xlabel('Length(in)')
ylabel('V - Normalized')


%% Four-Element Modal Response


[x4,v4] = eigenmode(L,ev4(:,1),4,10,1);
[x5,v5] = eigenmode(L,ev4(:,2),4,10,1);
[x6,v6] = eigenmode(L,ev4(:,3),4,10,1);

ModeFreq4 = freq4(1);
ModeFreq5 = freq4(2);
ModeFreq6 = freq4(3);

figure
hold on
Mode4 = sprintf('Mode Shape 1 %0.1f Hz',ModeFreq4);
Mode5 = sprintf('Mode Shape 2 %0.1f Hz',ModeFreq5);
Mode6 = sprintf('Mode Shape 3 %0.1f Hz',ModeFreq6);

plot(x4,v4/(max(v4)))
plot(x5,v5/(max(v5)))
plot(x6,v6/(max(v6)))

legend(Mode4,Mode5,Mode6,'Location','southwest')
xlim([0 12])
title('Modal Response 4-Element')
grid on
hold off
xlabel('Length(in)')
ylabel('V - Normalized')

%% Nick - Question 1:
Lambda = [12.37*2*pi, 0,          0,          0;
          0,          24.50*2*pi, 0,          0,
          0,          0,          42.09*2*pi, 0;
          0,          0,          0,          45.67*2*pi];

X = (K_red2 - Lambda*eye(4));

Lambda2 = [12.37*2*pi, 0,         0,          0;
          0,          24.50*2*pi, 0,          0,
          0,          0,          24.54*2*pi, 0;
          0,          0,          0,          45.67*2*pi];

X2 = (K_red2 - Lambda2*eye(4));

[x4b,v4b] = eigenmode(L,X(:,1),2,10,1);
[x5b,v5b] = eigenmode(L,X(:,2),2,10,1);
[x6b,v6b] = eigenmode(L,X2(:,3),2,10,1);
[x7b,v7b] = eigenmode(L,X(:,3),2,10,1);
[x8b,v8b] = eigenmode(L,X(:,4),2,10,1);

figure
plot(x4b,v4b/(max(v4b)))
hold on
plot(x5b,v5b/(max(v5b)))
plot(x6b,v6b/(-min(v6b)))
plot(x7b,v7b/(max(v7b)))
plot(x8b,v8b/(max(v8b)))
title('Mode shapes: Experimental')
xlabel('Length [in]')
ylabel('Amplitude')
grid on
legend('12.37 Hz', '24.50 Hz', '24.54 Hz', '42.09 Hz', '45.67 Hz', 'Location','southwest')
hold off

figure
plot(x4b,v4b/(max(v4b)))
hold on
plot(x1,v1/(max(v1)))
plot(x8b,v8b/(max(v8b)))
plot(x2,v2/(-min(v2)))
title('Mode shapes: Experimental vs. 2 Element')
xlabel('Length [in]')
ylabel('Amplitude')
grid on
legend('12.37 Hz - Experimental', '12.9 Hz - 2 Element', '45.67 Hz - Experimental', '54.0 Hz - 2 Element','Location','southwest')