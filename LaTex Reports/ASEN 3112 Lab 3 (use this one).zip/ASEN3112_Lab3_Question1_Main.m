%% ASEN 3112: Structures
% Lab 3 - Vibrations
% Author: Nick Bottieri
% Created on: April 11, 2022
% Last updated: April 17, 2022
% Purpose: Plots response on the system as a function of the excitation
% frequency (with a magnification factor applied).

%% Housekeeping
clc
clear all
close all

%% Reading Data file, Manipulating, and Plotting

%%% Read in data:
Data1a = readtable('ASEN3112_Lab3_1');
Data1 = table2array(Data1a);

%%% Fix time data incase the machine time was never reset:
Data1(:,1) = Data1(:,1) - Data1(1,1);

%%% Sampling Frequency + range of frequencies:
sz = size(Data1);
Fs = 1/(Data1(2,1)-Data1(1,1)); % Sampling frequency
f = Fs*(0:(sz(1)/2))/sz(1); % Range of frequencies

%%% FFTs:
tail_fft = fft(Data1(:,3));
wing_fft = fft(Data1(:,4));
nose_fft = fft(Data1(:,5));

%%% Tail fft manipulation:
P2 = abs(tail_fft/sz(1));
P1 = P2(1:sz(1)/2+1);
P1(2:end-1) = 2*P1(2:end-1);

%%% Wing fft manipulation:
P4 = abs(wing_fft/sz(1));
P3 = P4(1:sz(1)/2+1);
P3(2:end-1) = 2*P3(2:end-1);

%%% Nose fft manipulation:
P6 = abs(nose_fft/sz(1));
P5 = P6(1:sz(1)/2+1);
P5(2:end-1) = 2*P5(2:end-1);

%%% Plotting FFT:
figure
hold on
plot(f,P1/max(P1))
plot(f,P3/max(P3))
plot(f,P5/max(P5))
xlim([1 51])
xlabel('Frequency [Hz]','FontSize',16)
ylabel('FFT Amp.','FontSize',16)
title('FFT','FontSize',16)
legend('Tail','Wing','Nose','Location','northwest','FontSize',16)
