clear; close all; clc;

%Under the assumption that the wheel is a disk
m = 2.98; %kg
r = .32; %m
axle = 0.17; %m
g = 9.81; %m/s^2

% velocityActual = [37; 28; 50; 35]*(1000/3600);
velocityActual = [28; 35; 37; 50]*(1000/3600);
% timeActual = [7.35; 4.59; 9.63; 6.38];
timeActual = [4.59; 6.38; 7.35; 9.63];
wActual = velocityActual/r;

for i = 1:length(timeActual)
    thetaDotActual(i) = 2*pi/timeActual(i);
end

velocityPredicted = (0:.5:70)*(1000/3600);

I = [(1/4)*m*r^2 0 0; 0 (1/4)*m*r^2 0; 0 0 (1/2)*m*r^2];

for i = 1:length(velocityPredicted)
    wp(1:3,i) = [0; 0; velocityPredicted(i)/r];
end

Hp = I*wp;

L = axle*m*g;

for i = 1:length(Hp)
    thetaDotp(i) = L/Hp(3,i);
    timep(i) = 2*pi/thetaDotp(i);
end


figure
plot(wp(3,1:end),timep)
title('Predicted Period vs Wheel Spin Rate')
ylabel('Predicted Period [s]')
xlabel('Wheel Spin Rate [rad/s]')
hold on
scatter(wActual,timeActual)
legend('Predicted','Experimental','Location','Best')

figure
plot(wp(3, 1:end),thetaDotp)
title('Predicted Precession Rate vs Wheel Spin Rate')
xlabel('Wheel Spin Rate [rad/s]')
ylabel('Predicted Precession Rate [rad/s]')
hold on
scatter(wActual, thetaDotActual)
legend('Predicted','Experimental','Location','Best')

figure
plot(wp(3, 1:end),thetaDotp)
title('Predicted Precession Rate vs Wheel Spin Rate')
xlabel('Wheel Spin Rate [rad/s]')
ylabel('Predicted Precession Rate [rad/s]')
xlim([22 45])
hold on
scatter(wActual, thetaDotActual)
legend('Predicted','Experimental','Location','Best')

thetaerrors = thetaDotp([57 71 75 101]) -  thetaDotActual;
timeerrors = timep([57 71 75 101]) - timeActual';
