%% Header
% Zak Reichenbach
% Elena Bauer
% Matt Gozum
% Gavin O'Connell
%ASEN 3128
%Lab_1_Final.m
%Created: 8/24/21

%% Housekeeping
clear
clc
close all
%% Problem 1

tspan = [0 5];  %Time Span
y0 = [8; 5; 2]; %Initial Conditions

[t,f] = ode45(@(t,f) ODEfun(t,y0), tspan, y0);  %ODE call

%Plot
figure('NumberTitle', 'off', 'Name', '1.a Basic ODE')
title('1.a')
subplot(3,1,1)
plot(t,f(:,1),'r', 'LineWidth', 2)
title('X')
xlabel('Time [s]')

subplot(3,1,2)
plot(t,f(:,2),'g', 'LineWidth', 2)
title('Y')
xlabel('Time [s]')

subplot(3,1,3)
plot(t,f(:,3),'b', 'LineWidth', 2)
title('Z')
xlabel('Time [s]')




%% Problem 2
%% Problem 2b

%Constants
m = 0.03; %kg
dia = 0.03; %m
A = pi*(dia^2)/4;
rho = 1.225; %kg/m^3 at S.L.
Cd = 0.6; %coeff
g = 9.81; %m/s^2
x0 = [0,0,0,0,20,-20]'; % Initial Conditions
wind = [0,0,0];         % Initialize Wind Vec
tspan = [0 200];        % Time span

%ODE45 Call
opt = odeset('Events', @groundStrike);  %hit ground
[t1,j] = ode45(@(t,x) objectEOM(t,x,rho,Cd,A,m,g,wind), tspan, x0, opt);
%Distance
dest = [j(end,1), j(end,2)];   %Down range coordinates
distance = norm(dest);         %Total Down Range Distance

%Plot
figure()
%First Arc Trajectory
hold on
plot3(j(:,1), j(:,2), -j(:,3))      %Arc
plot3(j(1,1),j(1,2),-j(1,3),'go')   %Starting Point
title('Plain Trajectory')
zlabel('Z [m]')
ylabel('Y [m]')
xlabel('X [m]')
grid on

%Plot State Vectors
figure()
subplot(3,2,1)
plot(t1,j(:,1))
title('States vs. Time')
xlabel('Time [s]')
ylabel('X [m]')

subplot(3,2,3)
plot(t1,j(:,2))
xlabel('Time [s]')
ylabel('Y [m]')

subplot(3,2,5)
plot(t1,j(:,3))
xlabel('Time [s]')
ylabel('Z [m]')

subplot(3,2,2)
plot(t1,j(:,4))
xlabel('Time [s]')
ylabel('X Velocity [m/s]')

subplot(3,2,4)
plot(t1,j(:,5))
xlabel('Time [s]')
ylabel('Y Velocity [m/s]')

subplot(3,2,6)
plot(t1,j(:,2))
xlabel('Time [s]')
ylabel('Z Velocity [m/s]')


%% Problem 2C

N = 10;                             %Wind interations
randwind = randi([-100,100],3,N);   %Random Wind Value 
randwind(2:3,:) = 0;                %Wind only horizontal to path
distance2 = zeros(1,N);             %Preallocate Dist Vec
data1 = cell(N,2);                  %Stores: Left Column: Time-Right Column: Position

%Random wind with ODE45 over N iterations
for i =1 : N
    
    wind = randwind(:,i);               %Wind Vector
    windmag(i) = norm(wind);            %Total Wind Strength
    
    [t1,j1] = ode45(@(t,x) objectEOM(t,x,rho,Cd,A,m,g,wind), tspan, x0, opt);
    
    data1{i,1} = t1;                    %Grab ODE output for each varied wind
    data1{i,2} = j1;
    dest1 = [j1(end,1), j1(end,2)];     %Landing Coordinates
    distance2(i) = norm(dest1);         %Total distance travelled for each varied wind trajectory
        
end

%Data Collection

NoWindVec = [0;distance];          %No wind standard distance
Comparison = [windmag ; distance2]; 
Comparison = [NoWindVec Comparison];

%Plots the wind speed Vs Distance travelled
figure()
scatter(Comparison(2,1:N), Comparison(1,1:N));
title('Wind Speed Vs. Distance')
xlabel("Wind Speed Magnitude [m/s]")
ylabel("Distance [m]")

%Plot Trajectories
  figure()
  grid on
    for i = 1:N
      hold on  
      plot3(data1{i,2}(:,1), data1{i,2}(:,2), -data1{i,2}(:,3))
    end
title('Wind Trajectories')
xlabel('X [m]')
ylabel('Y [m]')
zlabel('Z [m]')
legend(string(wind))
hold off;

%% Problem 2d

N = 10;     %Masses
randmass = randi([0,200],1,N)/1000;   %Random Wind Value 
distance3 = zeros(1,N);     %Preallocate Dist Vec
data2 = cell(N,2);       %Stores: Left Column: Time-Right Column: Position
wind = [0;0;0];

%Random mass with ODE45 over N iterations
for i =1 : N
    
    mass(i) = randmass(:,i);               %Mass Vector
    
    [t2,j2] = ode45(@(t,x) objectEOM(t,x,rho,Cd,A,mass(i),g,wind), tspan, x0, opt);
    
    data2{i,1} = t2;                     %Grab ODE output for each varied wind
    data2{i,2} = j2;
    distance3(i) = j2(end,2);         %Total distance travelled for each varied wind trajectory
        
end

%Data Collection

StandardMassVec = [0;distance];          %Standard Mass standard distance
Comparison2 = [randmass ; distance3]; 
Comparison2 = [StandardMassVec Comparison2];

%Plots the wind speed Vs Distance travelled
figure()
scatter(Comparison2(1,1:N), Comparison2(2,1:N));
title('Mass Vs. Distance')
xlabel("Mass [kg]")
ylabel("Distance [m]")

%Plot Trajectories
figure()
grid on
    for i = 1:N
      hold on  
      plot3(data2{i,2}(:,1), data2{i,2}(:,2), -data2{i,2}(:,3))
    end
    
title('Mass Trajectories')
xlabel('X [m]')
ylabel('Y [m]')
zlabel('Z [m]')
legend(string(mass))
hold off;



%% Function Junction

%ODE45 Function for P1
function der = ODEfun(t,y0)

%Inputs: 3 differential equations for Xdot, Ydot, and Zdot
%
%Outputs: 2 Matrices, one for time and the other for [x y z] positions


%Initialization of starting components
x = y0(1);                  
y = y0(2);
z = y0(3);
%Derivatives that output x, y and z from ODE45
dxdt = x + 2*y + z;
dydt = x - 5*z;
dzdt = x*y - y.^2 + 3*z.^3;
der = [dxdt; dydt; dzdt];
end

%ODE45 Function for P2
function xdot = objectEOM(t,x,rho,Cd,A,m,g,wind)

%Inputs: density, Coefficient of Drag, Area, Mass, Gravity Acceleration,
%        Wind Vector, Time Span, Initial conditions [x y z Vx Vy Vz],
%        Ground Hit Conditions
%
%Outputs: [x y z Vx Vy Vz]
%
%Function uses Newtons Second Law with ODE45 to calculate ballistic
%trajectories given initial conditions with air drag.


%Velocities
xdot(1) = x(4); %Vx
xdot(2) = x(5); %Vy
xdot(3) = x(6); %Vz

airrel = x(4:6)- wind;     %Air Relative Velocity
airspeed = norm(airrel);   %Scalar Airspeed
DragMag = Cd*(rho*(airspeed)^2)*0.5*A;  %Drag Forec
unitvec = airrel/airspeed; %Unit coordinate frame for air relative velocity
DragF = -DragMag * unitvec;%Dragforce In proper frame

%Acceleration from Drag force & Gravity
xdot(4) = DragF(1)/m;       %Ax     
xdot(5) = DragF(2)/m;       %Ay
xdot(6) = DragF(3)/m + g;   %Az
xdot = xdot';               %Transpose matrix
end

% Ground Strike Function
function [value, isterminal, direction] = groundStrike(t,x)
    value = (x(3) <= 0);
    isterminal = 1;
    direction = 0;
end
