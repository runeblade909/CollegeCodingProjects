%% Question  3

      E = 10e+6; % psi, same for both
    L = 1:0.1:10; % in, same for both
    yield_stress = 35000;
    
    % rectangle
    h_r = 1; % in
    w  = 0.125;% in
    A_r = h_r*w;
    I_r = (h_r*w^3)/12;

    % Buckling Load
    Pcr_simp = pi^2.*E.*I_r./L.^2;

    Pcr_fix = 4.*pi^2.*E.*I_r./L.^2;

    % Compressive Yield Strength
    compLoad_r = yield_stress*A_r; % Load in which plastic deformation occurs

    figure;
    


    plot(L,Pcr_fix,'LineWidth',1.5)
    hold on
    plot(L,Pcr_simp,'LineWidth',1.5)
    yline(compLoad_r,'LineWidth',1.5)
    legend('Fixed  -  Fixed Beam','Simply Supported Beam','Compressive Yield Load')
    title(["Buckling Load as a function of Length","Rectangular Beam"])
    xlabel('Length (in)')
    ylabel('Load,P (lbs)')
    
    
    
    
    %% 
    E = 10e+6; % psi, same for both
    L = 1:0.1:10; % in, same for both
    yield_stress = 35000;
    
    % square
    side = 0.25; % in
    t = 0.0625; % in
    b =  side  -  2*t;
    I_s = side^4/12 - b^4/12;
    y_square = side/2;
    A_s = side*t*2 + (side-2*t)*t*2;

    % Buckling Load
    Pcr_simp = pi^2.*E.*I_s./L.^2;

    Pcr_fix = 4.*pi^2.*E.*I_s./L.^2;

    % Compressive Yield Strength
    compLoad_s = yield_stress*A_s; % Load in which plastic deformation occurs

    figure;
    


    plot(L,Pcr_fix,'LineWidth',1.5)
    hold on
    plot(L,Pcr_simp,'LineWidth',1.5)
    yline(compLoad_s,'LineWidth',1.5)
    legend('Fixed  -  Fixed Beam','Simply Supported Beam','Compressive Yield Load')
    title(["Buckling Load as a function of Length","Square Beam"])
    xlabel('Length (in)')
    ylabel('Load,P (lbs)')

 
  

