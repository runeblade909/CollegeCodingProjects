function ploteigenvector(L,ev,ne,nsub,scale)

% L = length of FEM mode
% ev = eigenvector to be plotted
% ne = number of beam finite elements
% nsub = number of subdivisions (usually 10)
% scale = scaling factor for eig values
% title = title of plot

nv = ne*nsub+1;
Le = L/ne;
dx = Le/nsub;
k=1;
x = zeros(1,nv);
v = x;

for e = 1:ne
    xi = Le *(e-1);
    vi = ev(2*e-1);
    qi = ev(2*e);
    vj = ev(2*e+1);
    qj = ev(2*e+2);

    for n = 1:nsub
        xk = xi+dx*n;
        xz= (2*n-nsub)/nsub;
        vk = scale*(0.125*(4*(vi+vj)+2*(vi-vj)*(xz^2-3)*xz...
            + Le*(xz^2-1)*(qj-qi+(qi+qj)*xz)));
        %k = k+1;
        x(k) = xk;
        v(k) = vk;
        k = k+1;
    end


end

plot(x(1:(end-1)),v(1:(end-1)),'--b',LineWidth=1.5);








end