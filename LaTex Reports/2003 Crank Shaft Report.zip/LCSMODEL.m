function [Beta,theta,velocity] = LCSMODEL(r , d, l, theta, w)
% This function calculates the velocity of the collar with the given input
% variables
%Written by: Jacob Starkel

w = w*((pi)/180);

    Beta = asind((d-r.*sind(theta))./l);
%RADIANS
    velocity = -w.*r.*(sind(theta)+cosd(theta).*tand(Beta));
    



end