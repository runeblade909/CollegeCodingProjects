clear;clc;close all;
loadData

%Physical Values
atmos_pressure = 12.750; %Atmospheric pressure in Psi
work_ideal = 3.12; %Inche Pounds per second

%Find average delta T for each trial
trial8.avg_dT = mean(data8.deltaT);
trial10.avg_dT = mean(data10.deltaT);
trial12.avg_dT = mean(data12.deltaT);

%Find average RPM of each trial
trial8.period = diff(data8.time(diff(data8.switch) == 1));
trial8.RPM = 60./trial8.period;
trial8.avg_RPM = mean(trial8.RPM);

trial10.period = diff(data10.time(diff(data10.switch) == 1));
trial10.RPM = 60./trial10.period;
trial10.avg_RPM = mean(trial10.RPM);

trial12.period = diff(data12.time(diff(data12.switch) == 1));
trial12.RPM = 60./trial12.period;
trial12.avg_RPM = mean(trial12.RPM);

%Find the middle point of the optical switch index for each trial for each
%rotation
indices = find(diff(data8.switch));
trial8.zeros = round(arrayfun(@(i) mean(indices(i:i+1)),1:2:length(indices)-2+1)', 0); % the averaged vector

indices = find(diff(data10.switch));
trial10.zeros = round(arrayfun(@(i) mean(indices(i:i+1)),1:2:length(indices)-2+1)', 0); % the averaged vector

indices = find(diff(data12.switch));
trial12.zeros = round(arrayfun(@(i) mean(indices(i:i+1)),1:2:length(indices)-2+1)', 0); % the averaged vector


% Sampling frequency for SW simulation
freqSW = 1/mean(diff(holeAngularDisplacement8.time));

% Adjust gauge pressure to absolute pressure
data8.deltaP = data8.deltaP + atmos_pressure;
data10.deltaP = data10.deltaP + atmos_pressure;
data12.deltaP = data12.deltaP + atmos_pressure;

% Sampling frequency for experimental data
trial8.freq = 1/mean(diff(data8.time));
trial10.freq = 1/mean(diff(data10.time));
trial12.freq = 1/mean(diff(data12.time));

%Offset Previously found zero points
offset8 = trial8.zeros(1);
offset10 = trial10.zeros(1);
offset12 = trial12.zeros(1);

trial8.zeros = trial8.zeros - offset8 + 1;
trial10.zeros = trial10.zeros - offset10 + 1;
trial12.zeros = trial12.zeros - offset12 + 1;

%Trim experimental data
data8 = data8(offset8:end, :);
data10 = data10(offset10:end, :);
data12 = data12(offset12:end, :);

%Reset elapsed time
data8.time = data8.time - data8.time(1);
data10.time = data10.time - data10.time(1);
data12.time = data12.time - data12.time(1);

%interpolate experimental data to line up with solidworks data
n = 10;
[data8.frame,  trial8.deltaPInterp] = alignData(n, holeAngularDisplacement8, data8, trial8);
[data10.frame, trial10.deltaPInterp] = alignData(n, holeAngularDisplacement10, data10, trial10);
[data12.frame, trial12.deltaPInterp] = alignData(n, holeAngularDisplacement12, data12, trial12);



%Offset small piston displacement so 0 corresponds to minimum volume
smallPiston8.displacement = ( smallPiston8.displacement - min(smallPiston8.displacement) )/1000;
smallPiston10.displacement = ( smallPiston10.displacement - min(smallPiston10.displacement) )/1000;
smallPiston12.displacement = ( smallPiston12.displacement - min(smallPiston12.displacement) )/1000;


%Find volume
r_smallPiston = 0.0115/2;
pistonArea = pi*r_smallPiston^2;
chamberVolume = 0.00017268;

smallPiston8.volume = chamberVolume + smallPiston8.displacement*pistonArea;
smallPiston10.volume = chamberVolume + smallPiston10.displacement*pistonArea;
smallPiston12.volume = chamberVolume + smallPiston12.displacement*pistonArea;

%Convert from m^3 to inches^3
smallPiston8.volume = smallPiston8.volume * 61023.7;
smallPiston10.volume = smallPiston10.volume * 61023.7;
smallPiston12.volume = smallPiston12.volume * 61023.7;

%Trim Volume and PressureData based off pressure
smallPiston8 = smallPiston8(~isnan(trial8.deltaPInterp),:);
trial8.deltaPInterp = trial8.deltaPInterp(~isnan(trial8.deltaPInterp));

smallPiston10 = smallPiston10(~isnan(trial10.deltaPInterp),:);
trial10.deltaPInterp = trial10.deltaPInterp(~isnan(trial10.deltaPInterp));

smallPiston12 = smallPiston12(~isnan(trial12.deltaPInterp),:);
trial12.deltaPInterp = trial12.deltaPInterp(~isnan(trial12.deltaPInterp));

% Calculate Net Work Out
netWork8 = calculateWork(smallPiston8, trial8);
netWork10 = calculateWork(smallPiston10, trial10);
netWork12 = calculateWork(smallPiston12, trial12);

%Calculate Actual Total Efficiency Value
actual_efficiency8 = 100 * (netWork8 / work_ideal);
actual_efficiency10 = 100 * (netWork10 / work_ideal);
actual_efficiency12 = 100 * (netWork12 / work_ideal);

%Calculate Theoretical Maximum Efficiency
theoretical_efficiency8 = 100 * ( 1 - ((mean(data8.temp_tb)+273.15)/(mean(data8.temp_bt) + 273.15)));
theoretical_efficiency10 = 100 * ( 1 - ((mean(data10.temp_tb)+273.15)/(mean(data10.temp_bt) + 273.15)));
theoretical_efficiency12 = 100 * ( 1 - ((mean(data12.temp_tb)+273.15)/(mean(data12.temp_bt) + 273.15)));

disp("--Actual Engine Efficiencies --");
disp("8 Degree: " + actual_efficiency8 + "%");
disp("10 Degree: " + actual_efficiency10 + "%");
disp("12 Degree: " + actual_efficiency12 + "%");
disp(" ");
disp("--Theoretical Engine Efficiencies --");
disp("8 Degree: " + theoretical_efficiency8 + "%");
disp("10 Degree: " + theoretical_efficiency10 + "%");
disp("12 Degree: " + theoretical_efficiency12 + "%");



figure;
%t = tiledlayout(1, 3);
%nexttile;
plot(smallPiston8.volume, trial8.deltaPInterp);
hold on
grid minor
title("$8^\circ$ C Temperature Difference", 'interpreter', 'latex', 'fontSize', 16);
xlabel("Volume [$in^3$]", 'interpreter', 'latex', 'fontSize', 18);
ylabel("Pressure [psi]", 'interpreter', 'latex', 'fontSize', 18);

%nexttile;
figure;
plot(smallPiston10.volume, trial10.deltaPInterp);
grid minor
title("$10^\circ$ C Temperature Difference", 'interpreter', 'latex', 'fontSize', 16);
xlabel("Volume [$in^3$]", 'interpreter', 'latex', 'fontSize', 18);
ylabel("Pressure [psi]", 'interpreter', 'latex', 'fontSize', 18);

figure;
plot(smallPiston12.volume, trial12.deltaPInterp);
grid minor
title("$12^\circ$ C Temperature Difference", 'interpreter', 'latex', 'fontSize', 22);
xlabel("Volume [$in^3$]", 'interpreter', 'latex', 'fontSize', 18);
ylabel("Pressure [psi]", 'interpreter', 'latex', 'fontSize', 18);

%legend(["$8^\circ$ difference", "$10^\circ$ difference", "$12^\circ$ difference"], 'interpreter', 'latex', 'fontSize', 16);

function [frame, deltaPInterp] = alignData(n, holeAngularDisplacement, data, trial)
    zeroAngle = islocalmin(abs(holeAngularDisplacement.angularDisplacement));
    zeroAngle(1) = 1;
    zeroAngleFrame = holeAngularDisplacement.frame(zeroAngle);

    frame = zeros(size(data,1),1);
    for i = 1:n
        frame2 = zeroAngleFrame(i);
        idx2 = trial.zeros(i);
        if(i == 1)
            idx1 = 1;
            frame1 = 1;
        else
            idx1 = trial.zeros(i-1);
            frame1 = zeroAngleFrame(i-1);
        end
        frame(idx1:idx2) = linspace(frame1,frame2,idx2-idx1+1);
    end

    frames = holeAngularDisplacement.frame;

    deltaPInterp = interp1(frame(frame ~= 0),data.deltaP(frame ~= 0),frames);
end


function [net_work_out_dot] = calculateWork(smallPiston, trial)
%% Calculate Work Done by the Device
min_points = find(islocalmin(smallPiston.volume) == 1);

%Trim data to single cycles
smallPiston = smallPiston(min_points(1):min_points(end), :);
trial.deltaPInterp = trial.deltaPInterp(min_points(1):min_points(end));

%Recalculate Minimum and Maximum Points
min_points = [1; find(islocalmin(smallPiston.volume) == 1); numel(smallPiston.volume)];
max_points = find(islocalmax(smallPiston.volume) == 1);

%Split data into top and bottom sections
numCycles = numel(min_points) - 1;
extrema = sort([min_points; max_points]);
topCycles_volume = 0; bottomCycles_volume = 0;
topCycles_pressure = 0; bottomCycles_pressure = 0;
work_in = 0; work_out = 0;
for n = 1:2:numel(extrema)-2
    top_volume = smallPiston.volume(extrema(n+1):extrema(n+2));
    bottom_volume = smallPiston.volume(extrema(n):extrema(n+1));
    top_pressure = trial.deltaPInterp(extrema(n+1):extrema(n+2));
    bottom_pressure = trial.deltaPInterp(extrema(n):extrema(n+1));
    
    work_in = work_in + abs(trapz(bottom_volume, bottom_pressure));
    work_out = work_out + abs(trapz(top_volume, top_pressure));
    
    topCycles_volume = [topCycles_volume; NaN; smallPiston.volume(extrema(n+1):extrema(n+2))];
    bottomCycles_volume = [bottomCycles_volume; NaN; smallPiston.volume(extrema(n):extrema(n+1))];
    topCycles_pressure = [topCycles_pressure; NaN; trial.deltaPInterp(extrema(n+1):extrema(n+2))];
    bottomCycles_pressure = [bottomCycles_pressure; NaN; trial.deltaPInterp(extrema(n):extrema(n+1))];
end

net_work_out = abs(work_out - work_in);
deltaT = smallPiston.time(end) - smallPiston.time(1);
net_work_out_dot = net_work_out / deltaT;

%Trim initialization value for plotting
topCycles_volume = topCycles_volume(2:end);
bottomCycles_volume = bottomCycles_volume(2:end);
topCycles_pressure = topCycles_pressure(2:end);
bottomCycles_pressure = bottomCycles_pressure(2:end);

% close all;
% plot(topCycles_volume, topCycles_pressure);
% hold on
% plot(bottomCycles_volume, bottomCycles_pressure);
% legend(["Top", "Bottom"]);
% grid minor
end