%% Load Data Script
%This script is called from main
%It loads in 3 different data sets and calculates a new
%column of temperature differences

warning('off','MATLAB:table:ModifiedAndSavedVarnames')

%% Experimental Data
% load data
data8 = readtable("Group17_8C");
data10 = readtable("Group17_10C");
data12 = readtable("Group17_12C");

% set variable names
data8.Properties.VariableNames = ["time","deltaP","current","switch","temp_tt","temp_tb","temp_bt","temp_bb"];
data10.Properties.VariableNames = ["time","deltaP","current","switch","temp_tt","temp_tb","temp_bt","temp_bb"];
data12.Properties.VariableNames = ["time","deltaP","current","switch","temp_tt","temp_tb","temp_bt","temp_bb"];

%Temperature difference
data8.deltaT = data8.temp_bt - data8.temp_tb;
data10.deltaT = data10.temp_bt - data10.temp_tb;
data12.deltaT = data12.temp_bt - data12.temp_tb;


%% Solidworks Data

smallPiston8 = readtable('8CSmallPiston.xlsx');
smallPiston8.Properties.VariableNames = ["frame","time","displacement"];
holeAngularDisplacement8 = readtable('8CHoleAngularDisplacement.xlsx');
holeAngularDisplacement8.Properties.VariableNames = ["frame","time","angularDisplacement"];

smallPiston10 = readtable('10CSmallPiston.xlsx');
smallPiston10.Properties.VariableNames = ["frame","time","displacement"];
holeAngularDisplacement10 = readtable('10CHoleAngularDisplacement.xlsx');
holeAngularDisplacement10.Properties.VariableNames = ["frame","time","angularDisplacement"];

smallPiston12 = readtable('12CSmallPiston.xlsx');
smallPiston12.Properties.VariableNames = ["frame","time","displacement"];
holeAngularDisplacement12 = readtable('12CHoleAngularDisplacement.xlsx');
holeAngularDisplacement12.Properties.VariableNames = ["frame","time","angularDisplacement"];
