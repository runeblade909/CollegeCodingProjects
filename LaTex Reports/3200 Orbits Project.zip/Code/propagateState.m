function x = propagateState(oe0,t,t_0,MU,J2,Re)
%DESCRIPTION: Computes the propagated position and velocity in km, km/s
%accounting for approximate J2 perturbations
%
%INPUTS:
% oe0       Orbit elements [a,e,i,Om,om,f] at time t0 (km,s,rad)
% t         Current time (s)
% t0        Time at the initial epoch (s)
% MU        Central body's gravitational constant (km^3/s^2)
% J2        Central body's J2 parameter (dimensionless)
% Re        Radius of central body (km)
%
%OUTPUTS:
% x         Position and velocity vectors of the form [r; rdot] (6x1) at
%             time t


%make sure that function has outputs
x = NaN(6,1);

%% 1) Compute the mean orbit elements oe(t) at time t due to J2 perturbations
n = sqrt(MU/oe0(1)^3);
p = oe0(1) * (1-oe0(2)^2); %Semi Major Axis [km]
Omega = -3/2 *n*J2*(Re/p)^2*cos(oe0(3)); %Om due to J2 pert [rad/sec?]
omega = 3/2*n*J2*(Re/p)^2*(2-5/2*sin(oe0(3))^2); %om due to J2 pert  [rad/sec?]
a = oe0(1);
e = oe0(2);
i = oe0(3);
Eadd = 2*atan(tan(oe0(6)/2)*sqrt((1-e)/(1+e)));
%% 2) Solve the time-of-flight problem to compute the true anomaly at time t
tolerance = 1.e-8; %Setting Newton's Method Tolerance

dt = t - t_0;
M = n * (dt);
if M < pi
    E = M + e/2;
else
    E = M - e/2;
end

ratio = 1;
while abs(ratio) > tolerance
    ratio = (E - e*sin(E) - M)/(1 - e*cos(E));
    E = E - ratio;
end
f = 2*atan(sqrt((1+e)/(1-e))*tan(E/2));
Ecalc = E+Eadd; %Eccentric anomaly at time t
fcalc = f + oe0(6); %true anomaly at time t

%% 3) Compute r(t), rdot(t) in the perifocal frame
%Calculate rdot(t)
x(4) = sqrt(MU/p) * -sin(fcalc);
x(5) = sqrt(MU/p) * (e+cos(fcalc));
x(6) = 0;

%calculate r(t)
x(1) = (a*(e*cos(Ecalc)-e^2))/e;
x(2) = a*sqrt(1-e^2)*sin(Ecalc);
x(3) = 0;

%% 4) Compute r(t), rdot(t) in the ECI frame, save into x
%compute DCM from parafocal to ECI
C1 = cos(omega)*cos(Omega)-sin(omega)*cos(i)*sin(Omega);
C2 = cos(omega)*sin(Omega)+sin(omega)*cos(i)*cos(Omega);
C3 = sin(omega)*sin(i);
C4 = -sin(omega)*cos(Omega)-cos(omega)*cos(i)*sin(Omega);
C5 = -sin(omega)*sin(Omega)+cos(omega)*cos(i)*cos(Omega);
C6 = cos(omega)*sin(i);
C7 = sin(i)*sin(Omega);
C8 = -sin(i)*cos(Omega);
C9 = cos(i);
DCM = [C1,C2,C3;C4,C5,C6;C7,C8,C9]'; %DCM from parafocal to ECI

%convert r(t) and rdot(t) to ECI from parafocal
x(1:3) = DCM*x(1:3);
x(4:6) = DCM*x(4:6);
x = x';
end