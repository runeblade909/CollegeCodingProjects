function [num_launches, num_spacecraft, satellite_list] = loadConstellation(filename)
    %DESCRIPTOIN: Ingests constellation description .json file and parses it
    %into a list of structs with full initial orbit elements (km, s, rad) and
    %satellite name.
    %
    %INPUTS:
    % filename      A string indicating the name of the .json file to be parsed
    %
    %OUTPUTS:
    % nl            Number of total launches
    % ns            Total number of spacecraft between all launches
    % satlist       Array of structs with 'name' and 'oe0' properties
    
    %% Load .json file
    fname = filename; 
    fid = fopen(fname); 
    fid = 3;
    raw = fread(fid,inf); 
    str = char(raw'); 
    fclose(fid);
    data = jsondecode(str);
    
    %% Pre-Allocate Arrays
    num_spacecraft = 0;
    num_launches = length(data.launches);
    for i = 1:num_launches
        for j = 1:length(data.launches(i).payload)
            num_spacecraft = num_spacecraft+1;
        end
    end
    satellite_list = struct;
    %% Populate each entry in the satellite struct list with its name and
    %initial orbit elements [a,e,i,Om,om,f] at time t0
    k = 1;
    for i = 1:num_launches
        for j = 1:length(data.launches(i).payload)
            satellite_list(k).name = data.launches(i).payload(j).name;
            satellite_list(k).oe0 = [data.launches(i).orbit.a,data.launches(i).orbit.e,data.launches(i).orbit.i,data.launches(i).orbit.Om,data.launches(i).orbit.om,data.launches(i).payload(j).f];
            satellite_list(k).AzimuthShift = data.launches(i).orbit.AzimuthShift;
            k = k+1;
        end
    end
end
