%Main
%Christopher Lolkema
%ASEN3200 Orbital Projects Part 1 Code
tic %Start Time Elapsed Calc

%% Set Up Coding Environment

clear;
clc;
close all;

%% Constants

mu = 3.98e14/1000^3; %Gravitational Parameter [km^3/sec^2]
J2 = 1.087e-3; %Pertibations [dimensionless]
Re = 6378; %Radius of Earth [km]
timeVec = [0:60:86400];
timeLength = length(timeVec);

%% Load World Cities Data and CoastLine Data

cities = readtable("worldcities.csv");
coastline = readtable("world_coastline_low.txt");

[coastX,coastY,coastZ] = sph2cart(pi/180*coastline{:,1},pi/180*coastline{:,2},Re);


%% Limit Amount of Cities for Testing

cities = cities(1:end,:);
[numCities,~] = size(cities);
for i = 1:numCities
    if isnan(cities{i,10})
        cities{i,10} = 0;
    end
end

%% Load JSON File

filename = "Constellation.json";
[num_launches, num_spacecraft, satellite_list] = loadConstellation(filename);

%% Propagate State

hold on
for j = 1:num_spacecraft
    t_0 = 0;
    k = 1;
    orbits = zeros(timeLength,6);
    for i = timeVec
        t = i;
        orbits(k,:) = propagateState(satellite_list(j).oe0,t,t_0,mu,J2,Re);
        k = k + 1;
    end
    satellite_list(j).orbitmat = orbits;
end

%% Convert ECEF

for i = 1:num_spacecraft
    statevec = satellite_list(i).orbitmat;
    [azimuth,elevation,r] = cart2sph(statevec(:,1),statevec(:,2),statevec(:,3));
    azimuth = (180/pi .* azimuth) - (360/86400).*timeVec'+180/pi.*satellite_list(i).AzimuthShift;
    elevation = 180/pi * elevation;
    [maxr,maxi] = max(azimuth);
    [minr,mini] = min(azimuth);
    while maxr > 180 || minr < -180
        for j = 1:length(azimuth)
            if azimuth(j) > 180
                azimuth(j) = azimuth(j) - 360;
            end
            if azimuth(j) < -180
                azimuth(j) = azimuth(j) + 360;
            end
        end
        [maxr,maxi] = max(azimuth);
        [minr,mini] = min(azimuth);
    end
    [x,y,z] = sph2cart(pi/180*azimuth, pi/180*elevation, r);
    satellite_list(i).ecef  = [x,y,z];
end

%% Compute LoS

%Plot Cities
[siteRX,siteRY,siteRZ] = sph2cart(pi/180*cities{:,4},pi/180*cities{:,3},Re);
angleTest = pi/180 * 15;
angleTest = cos(pi/2-angleTest);
numOrbitalPoints = timeLength;
cityStruct = struct([]);
for i = 1:numCities
    siteR = [siteRX(i),siteRY(i),siteRZ(i)];
    sumVec = zeros(numOrbitalPoints,1);
    for j = 1:numOrbitalPoints
        sumVal = 0;
        for k = 1:num_spacecraft
            sumVal = sumVal + testLoS(siteR,satellite_list(k).ecef(j,:),angleTest);
        end
        sumVec(j) = sumVal;
    end
    cityStruct(i).LoS = sumVec;
end

%% Number of Spacecrfat weighted by Populatoin in view of Cities Plot

figure
weightSum = 0;
sumVec = zeros(1,numOrbitalPoints);
for i = 1:numOrbitalPoints
    sumadd = 0;
    for j = 1:numCities
        sumadd = cityStruct(j).LoS(i)*cities{j,10} + sumadd;
    end
    sumVec(i) = sumadd;
end
plot(timeVec,sumVec)
xlabel("Time [sec]")
ylabel("Weighted Satellite Line of Sight")
title("Weighted Satellite Line of Site as a function of Time")
%% Calculate Cost

value = 0;
for i = 1:numCities
    value = value + cities{i,10}/(timeVec(end))*sum(cityStruct(i).LoS);
    if isnan(value)
        breakIndex = i;
        break
    end
end

cost = 100e6*num_launches + 5e6*num_spacecraft
ratio = value/cost

%% Ground Track Plot

figure
xlim([-180,180])
ylim([-90,90])
xlabel("Latitude")
ylabel("Longitude")
hold off
TimeElapsed = toc/60
%Plot Orbits
colorVec = zeros(1,numCities);
for j = 1:length(satellite_list(1).ecef(:,1))
    plot(coastline{:,1},coastline{:,2},'k')
    xlim([-180,180])
    ylim([-90,90])
    hold on
    for k = 1:numCities
        colorVec(k) = cityStruct(k).LoS(j);
    end
    scatter(cities{:,4},cities{:,3},5,colorVec,'filled')
    for i = 1:num_spacecraft
        [Az,Ele,~] = cart2sph(satellite_list(i).ecef(j,1),satellite_list(i).ecef(j,2),satellite_list(i).ecef(j,3));
        scatter(180/pi*Az,180/pi*Ele,'.r')
    end
    colorbar('East')
    hold off
    print(['Frame ' num2str(j)], '-dpng', '-r150');
end

%% Plot 3D Orbit
% xlim([-6500,6500])
% ylim([-6500,6500])
% zlim([-6500,6500])
[X,Y,Z] = sphere();
X = .98*Re*X;
Y = .98*Re*Y;
Z = .98*Re*Z;
% figure 
% view(3)
% axis equal
figure
view(3)
axis equal
for i = 1:numOrbitalPoints
    mesh(X,Y,Z)
    hold on
    scatter3(siteRX,siteRY,siteRZ,20,'.b')
    scatter3(coastX,coastY,coastZ,5,'.k')
    for j = 1:num_spacecraft
        scatter3(satellite_list(j).ecef(i,1),satellite_list(j).ecef(i,2),satellite_list(j).ecef(i,3),'.r')
    end
    hold off
    print(['Frame3D ' num2str(j)], '-dpng', '-r150');
end

%% Export GIF

GifName = 'SatelliteConstellation.gif';
delay = 0.0001;    % Delay between frames (s)
for ii = 1:length(satellite_list(i).ecef(:,1))
    [A, ~] = imread(['Frame ' num2str(ii) '.png']);
    [X, map] = rgb2ind(A, 256);
    if ii == 1
        imwrite(X, map, GifName, 'gif', 'LoopCount', inf, 'DelayTime', delay)
    else
        imwrite(X, map, GifName, 'gif', 'WriteMode', 'append', 'DelayTime', delay)
    end
end

GifName = 'SatelliteConstellation3D.gif';
for ii = 1:length(satellite_list(i).ecef(:,1))
    [A, ~] = imread(['Frame3D ' num2str(ii) '.png']);
    [X, map] = rgb2ind(A, 256);
    if ii == 1
        imwrite(X, map, GifName, 'gif', 'LoopCount', inf, 'DelayTime', delay)
    else
        imwrite(X, map, GifName, 'gif', 'WriteMode', 'append', 'DelayTime', delay)
    end
end

%% Plot Final 3D Sat Orbit
    figure
    mesh(X,Y,Z)
    hold on
    scatter3(siteRX,siteRY,siteRZ,20,'.b')
    scatter3(coastX,coastY,coastZ,5,'.k')
    for j = 1:num_spacecraft
        scatter3(satellite_list(j).ecef(end,1),satellite_list(j).ecef(end,2),satellite_list(j).ecef(end,3),'.r')
    end
    title("Final Position of Satellites With Respect to Earth")
%% Time Elapsed

timeElapse = toc/60;
disp(num2str(timeElapse))
disp(' Minutes Elapsed')