%% Housekeeping
clc, clear all, close all

%% Data:

Memsdata1 = importdata("2021_XX_XX_TH_UNIT05_MEMS_F#.25_C#1");
Memsdata2 = importdata("2021_XX_XX_TH_UNIT05_MEMS_F#.5_C#2.5");
Memsdata3 = importdata("2021_XX_XX_TH_UNIT05_MEMS_F#.75_C#.75");
Memsdata4 = importdata("2021_XX_XX_TH_UNIT05_MEMS_F#1_C#.5");
Memsdata5 = importdata("2021_XX_XX_TH_UNIT05_MEMS_MAN");

%% MEMS Gyro Measurments:

% Data 1
figure(1)
plot(Memsdata1.data(:,3)*2*pi/60, Memsdata1.data(:,2))
p1 = polyfit(Memsdata1.data(:,3)*2*pi/60, Memsdata1.data(:,2), 1);
hold on

x1 = -8:10;
y1 = p1(1) * x1 + p1(2);
plot(x1, y1, 'LineWidth', 1.8);
grid on
title("Gyro vs. Encoder Angular Velocity");
xlabel("Encoder velocity [rad/s]"); ylabel("Gyro Velocity [rad/s]");
legend('Experiment', 'Line Fit');

caption1 = sprintf('y = %f x + %f', p1(1), p1(2));
text(-5,-5, caption1, 'FontSize', 16)
% Data 2
figure(2)
plot(Memsdata2.data(:,3)*2*pi/60, Memsdata2.data(:,2))
p2 = polyfit(Memsdata2.data(:,3)*2*pi/60, Memsdata2.data(:,2), 1);
hold on

x2 = -1:1;
y2 = p2(1) * x2 + p2(2);
plot(x2, y2, 'LineWidth', 1.8);
grid on
title("Gyro vs. Encoder Angular Velocity");
xlabel("Encoder velocity [rad/s]"); ylabel("Gyro Velocity [rad/s]");
legend('Experiment', 'Line Fit');
caption2 = sprintf('y = %f x + %f', p2(1), p2(2));
text(-0.5,-0.5, caption2, 'FontSize', 16)

% Data 3
figure(3)
plot(Memsdata3.data(:,3)*2*pi/60, Memsdata3.data(:,2))
p3 = polyfit(Memsdata3.data(:,3)*2*pi/60, Memsdata3.data(:,2), 1);
hold on

x3 = -3:3;
y3 = p3(1) * x3 + p3(2);
plot(x3, y3, 'LineWidth', 1.8);
grid on
title("Gyro vs. Encoder Angular Velocity");
xlabel("Encoder velocity [rad/s]"); ylabel("Gyro Velocity [rad/s]");
legend('Experiment', 'Line Fit');
caption3 = sprintf('y = %f x + %f', p3(1), p3(2));
text(-2,-2, caption3, 'FontSize', 16)

% Data 4
figure(4)
plot(Memsdata4.data(:,3)*2*pi/60, Memsdata4.data(:,2))
p4 = polyfit(Memsdata4.data(:,3)*2*pi/60, Memsdata4.data(:,2), 1);
hold on

x4 = -1:2;
y4 = p4(1) * x4 + p4(2);
plot(x4, y4, 'LineWidth', 1.8);
grid on
title("Gyro vs. Encoder Angular Velocity");
xlabel("Encoder velocity [rad/s]"); ylabel("Gyro Velocity [rad/s]");
legend('Experiment', 'Line Fit');
caption4 = sprintf('y = %f x + %f', p4(1), p4(2));
text(-0.5,-1, caption4, 'FontSize', 16)


% Data 5
figure(5)
plot(Memsdata5.data(:,3)*2*pi/60, Memsdata5.data(:,2))
p5 = polyfit(Memsdata5.data(:,3)*2*pi/60, Memsdata5.data(:,2), 1);
hold on

x5 = -3:3;
y5 = p5(1) * x5 + p5(2);
plot(x5, y5, 'LineWidth', 1.8);
grid on
title("Gyro vs. Encoder Angular Velocity");
xlabel("Encoder velocity [rad/s]"); ylabel("Gyro Velocity [rad/s]");
legend('Experiment', 'Line Fit');
caption5 = sprintf('y = %f x + %f', p5(1), p5(2));
text(-2,-2, caption5, 'FontSize', 16)


slopeAvg = (p1(1) + p2(1) + p3(1) + p4(1))/4;
offsetAvg = (p1(2) + p2(2) + p3(2) + p4(2))/4;

dt = Memsdata4.data(4,1) - Memsdata4.data(3,1);
Wvalue = (Memsdata4.data(:,2)-offsetAvg)/slopeAvg;

angPos = Wvalue * dt;

figure(6)
plot(Memsdata4.data(2:end,1)-Memsdata4.data(2,1), angPos(2:end))
grid on
title("Angular Position vs. Time");
ylabel("Angular Positon [rad]"); xlabel("Time [s]");
hold on
plot(Memsdata4.data(2:end,1)-Memsdata4.data(2,1), Memsdata4.data(2:end, 3)*dt)
legend('Gyro Position', 'Encoder Position')

figure(7)
plot(Memsdata5.data(2:end,1)-Memsdata5.data(2,1), Memsdata5.data(2:end,2))
grid on 
title("Angular Velocity vs. Time");
ylabel("Angular Velocity [rad/s]"); xlabel("Time [s]");

