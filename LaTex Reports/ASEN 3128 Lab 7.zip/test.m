
clc
close all
clear all

%% Simple
% A = [-1.3256 -0.5415 -0.4313;...
%     -0.5415 -1.4162 -0.0523;...
%     -0.4313 -0.0523 -0.6582];
% C = [1 1 1];
% B = zeros(3,3);
% C = eye(3)
% x0 = [0.05 0.9 1.0]';
% 
% sys = ss(A,B,C,[]);
% initial(sys,x0,15)

%% Complex
clear all
A = [-0.0129 -0.0059 0 -0.0507;...
    -.104 -.8185 1 0;...
    0.2867 -12.6811 -1.424 0;...
    0 0 1 0];
B = zeros(4,4);
C = eye(4);
[v,d]=eig(A);
v1 = v(:,1);
v3 = v(:,3);
x0v1 = real(v1);
x0v3 = real(v3);

sys = ss(A,B,C,[]);

[y,t,~] = initial(sys,x0v1,8);
[y2,t2,~] = initial(sys,x0v3,800);


figure
hold on
plot(t,y(:,1))
plot(t,y(:,2))
plot(t,y(:,3))
plot(t,y(:,4))
hold off

figure
hold on
plot(t2,y2(:,1))
plot(t2,y2(:,2))
plot(t2,y2(:,3))
plot(t2,y2(:,4))


figure
M = [real(v1)';imag(v1)'];
plotv(M)

