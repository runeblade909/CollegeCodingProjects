% Ashwin Raju Abraham Jaet
% ASEN 3112
% lab1.m
% Created: 2/04/2022

%% Housekeeping
clear
clc
close all

%% Constants
De = .75; % Exterior Diameter [in]
thic = 1/16; % Uniform Wall Thickness [in]
L = 10; % Distance between Grips [in]
G = 3.75 * 10^6; % Shear Modulus [psi]
Re = De/2; % Exterior Tube Radius [in]
Ri = Re-thic;

%% Analytical Torsional Rigidity
R = (Re+Ri)/2;

% Closed Thin Wall Theory
Ae = pi*R^2;
p = 2*pi*R;
J_CTW = (4*thic*Ae^2)/p;
GJ_CTW = G*J_CTW;

% Open Thin Wall Theory
b = 2*pi*R;
if (b/thic) > 10
    alpha = 1/3;
    beta = 1/3;
end
J_OTW = alpha*b*thic^3;
GJ_OTW = G*J_OTW;


%% Closed Wall Data

% Import and Order Data
closedWallData = load('400inlbf_03.txt');
t_Closed = closedWallData(:,1); %time [s]
twistAngle_Closed = deg2rad( closedWallData(:,2) ); % Twist Angle [rad]
gammaExt_Closed = deg2rad( closedWallData(:,3) ); % Extensometer Strain [rad]
torque_Closed = closedWallData(:,4); % Torque [in*lbs]

% Zero the angle data
twistAngle_Closed = twistAngle_Closed - twistAngle_Closed(1);
gammaExt_Closed = gammaExt_Closed - gammaExt_Closed(1);

% Find strain from twist angle data
gammaGrip_Closed = twistAngle_Closed*(Re/L); 


% Line Fitting Extensometer Strain
line1 = fitlm(gammaExt_Closed, torque_Closed, 'poly1');
coeffs1 = table2array(line1.Coefficients);
lineExt_Closed = [coeffs1(2,1) coeffs1(1,1)];
yExt_Closed = polyval(lineExt_Closed, gammaExt_Closed);

% Find Extensometer Torsional Rigidity, Uncertainty, Percent Error
GJ_Ext_Closed = lineExt_Closed(1)*Re;
sigmaGJ1 = coeffs1(2,2)*Re;
percentError1 = abs( (GJ_CTW-GJ_Ext_Closed)/GJ_Ext_Closed)*100;

% Line Fitting Encoder Strain
line2 = fitlm(gammaGrip_Closed, torque_Closed, 'poly1');
coeffs2 = table2array(line2.Coefficients);
lineGrip_Closed = [coeffs2(2,1) coeffs2(1,1)];
yGrip_Closed = polyval(lineGrip_Closed, gammaGrip_Closed);

% Find Encoder Torsional Rigidity, Uncertainty, Percent Error
GJ_Grip_Closed = lineGrip_Closed(1)*Re;
sigmaGJ2 = coeffs2(2,2)*Re;
percentError2 = abs( (GJ_CTW-GJ_Grip_Closed)/GJ_Grip_Closed)*100;

% Plots
figure(1);
subplot(2,1,1); 
plot(gammaExt_Closed, torque_Closed,'LineWidth',1.5);
hold on;
title('Extensiometer \gamma vs. Torque');
ylabel('Torque [in*lbs]');
xlabel('\gamma [rad]');
plot(gammaExt_Closed, yExt_Closed,'LineWidth',1.5)
GJstr1 = sprintf('GJ = %.1f',GJ_Ext_Closed);
legend('Torque-Strain Curve', GJstr1,'Location','Best')

subplot(2,1,2);
plot(gammaGrip_Closed, torque_Closed,'LineWidth',1.5);
hold on
title('Calculated Encoder \gamma vs. Torque');
ylabel('Torque [in*lbs]');
xlabel('\gamma [rad]');
plot(gammaGrip_Closed, yGrip_Closed,'LineWidth',1.5);
GJstr2 = sprintf('GJ = %.1f',GJ_Grip_Closed);
legend('Torque-Strain Curve', GJstr2,'Location','Best')

sgtitle('Closed Thin Wall Specimen') 

%% Open Wall Data

% Import and Order Data
openWallData = load('20inlbf_03.txt');
t_Open = openWallData(:,1); %time [s]
twistAngle_Open = deg2rad( openWallData(:,2) ); % Twist Angle [rad]
gammaExt_Open = deg2rad( openWallData(:,3) ); % Extensometer Strain [rad]
torque_Open = openWallData(:,4); % Torque [in*lbs]

% Zero the angle data
twistAngle_Open = twistAngle_Open - twistAngle_Open(1);
gammaExt_Open = gammaExt_Open - gammaExt_Open(1);

% Find strain from twist angle data
gammaGrip_Open = twistAngle_Open*(thic/L);

% Line Fitting Extensometer Strain
line3 = fitlm(gammaExt_Open, torque_Open, 'poly1');
coeffs3 = table2array(line3.Coefficients);
lineExt_Open = [coeffs3(2,1) coeffs3(1,1)];
yExt_Open = polyval(lineExt_Open, gammaExt_Open);

% Find Extensometer Torsional Rigidity, Uncertainty, Percent Error
GJ_Ext_Open = lineExt_Open(1)*thic;
sigmaGJ3 = coeffs3(2,2)*thic;
percentError3 = abs( (GJ_OTW-GJ_Ext_Open)/GJ_Ext_Open)*100;

% Line Fitting Encoder Strain
line4 = fitlm(gammaGrip_Open, torque_Open, 'poly1');
coeffs4 = table2array(line4.Coefficients);
lineGrip_Open = [coeffs4(2,1) coeffs4(1,1)];
yGrip_Open = polyval(lineGrip_Open, gammaGrip_Open);

% Find Encoder Torsional Rigidity, Uncertainty, Percent Error
GJ_Grip_Open = lineGrip_Open(1)*thic;
sigmaGJ4 = coeffs4(2,2)*thic;
percentError4 = abs( (GJ_OTW-GJ_Grip_Open)/GJ_Grip_Open)*100;

% Plots
figure(2);

subplot(2,1,1);
plot(gammaExt_Open,torque_Open);
hold on
title('Extensiometer \gamma vs. Torque');
ylabel('Torque [in*lbs]');
xlabel('\gamma [rad]');
plot(gammaExt_Open, yExt_Open,'LineWidth',1.5)
GJstr3 = sprintf('GJ = %.1f',GJ_Ext_Open);
legend('Torque-Strain Curve', GJstr3,'Location','Best')

subplot(2,1,2); 
plot(gammaGrip_Open,torque_Open);
hold on
title('Calculated Encoder \gamma vs. Torque');
ylabel('Torque [in*lbs]');
xlabel('\gamma [rad]');
plot(gammaGrip_Open, yGrip_Open,'LineWidth',1.5);
GJstr4 = sprintf('GJ = %.1f',GJ_Grip_Open);
legend('Torque-Strain Curve', GJstr4,'Location','Best')



sgtitle('Open Thin Wall Specimen') 













